.. toctree::
   :maxdepth: 2

   kitti_det.md
   nuscenes_det.md
   lyft_det.md
   waymo_det.md
   sunrgbd_det.md
   scannet_det.md
   scannet_sem_seg.md
   s3dis_sem_seg.md
